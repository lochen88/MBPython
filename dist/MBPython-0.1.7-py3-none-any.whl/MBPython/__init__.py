# -*- coding:utf-8 -*-
from .seticon import set_icon
from .screenshot import screen_shot
from . import miniblink